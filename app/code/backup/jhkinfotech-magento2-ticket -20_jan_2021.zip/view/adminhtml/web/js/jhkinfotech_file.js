define([
    'jquery',
    'mage/url'
 ], function ($, url) {
   
   
});
