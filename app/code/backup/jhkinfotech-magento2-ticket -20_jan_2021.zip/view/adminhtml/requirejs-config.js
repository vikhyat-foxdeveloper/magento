var config = {
    paths: {
        'ticket': 'Jhkinfotech_Ticket/js/jhkinfotech_file'
    },
    shim: {
        'ticket': {
            deps: ['jquery']
        }
    }
};