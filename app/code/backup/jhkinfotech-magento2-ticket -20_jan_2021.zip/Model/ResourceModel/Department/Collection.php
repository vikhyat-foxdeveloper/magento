<?php

/**
 * @copyright  Copyright (c) 2021 Jhkinfotech  (https://jhkinfotech.com/)
 */

namespace Jhkinfotech\Ticket\Model\ResourceModel\Department;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'department_id';
    /**
     * Define resource model.
     */

    protected function _construct()
    {
        $this->_init('Jhkinfotech\Ticket\Model\Department', 'Jhkinfotech\Ticket\Model\ResourceModel\Department');
    }
}
