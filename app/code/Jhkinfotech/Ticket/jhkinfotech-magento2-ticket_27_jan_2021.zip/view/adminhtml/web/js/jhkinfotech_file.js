define([
    'jquery',
    'mage/url',
    'jquery/ui',
    'jquery/validate',
    'mage/translate'
 ], function ($, url) {
   
   
});
