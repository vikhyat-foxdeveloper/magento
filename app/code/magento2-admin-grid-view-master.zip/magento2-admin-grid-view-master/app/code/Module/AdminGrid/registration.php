<?php
/**
 * Module AdminGrid module registration
 * @package Module/AdminGrid
 */
declare(strict_types=1);

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Module_AdminGrid',
    __DIR__
);
